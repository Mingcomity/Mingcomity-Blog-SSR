<script lang="ts" setup></script>

<template>
  <div>
    Page: index
  </div>
</template>

<style scoped></style>
